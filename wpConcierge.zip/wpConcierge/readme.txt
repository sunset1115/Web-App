=== wpConcierge ===
Contributors: sunset.co
Donate link: https://live.gotoassist.com/explore-sdk/
Tags: Live Chat, Video Chat
Requires at least: 1.0
Tested up to: 1.0
Stable tag: 1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

wpConcerige is an Live chat plugin with optional live.gotoassist.com sdk. The Plugin provides an easy-to-integrate basic user interface allowing visitors, clients and customers to do live chat by clicking simple button.

The Live Chat button can be turned on and off for the front-side of the website. In the administration area there is a setting page which customize the Live Chat sdk. 

This plugin is great for when you implement the functions such as Help Chat, Video and Call Chat with simple setting options.

Main Features
-------------
Customize Live Chat buttons style.
Setting Call Chat function.
Implement Video Call Chat.


== Installation ==

To install, simply upload the plugin zip file to your Wordpress website and activate it. Configure the simple settings in the new menu 'Concierge' that will appear in your admin menu bar. Explanations of each feature accompany the inputs.

To add the plugin to your website, simply add this shortcode: [wpCon_livechat]

After first activation, the database will contain some new rows in the options table, option-name prefix: "wpCon_", containing a short pipe delimited string to store the plugin settings.


== Frequently Asked Questions ==


== Upgrade Notice ==

1.0.0 - First Update - Minor Changes

== Screenshots ==

1. screenshot_1.png

== Changelog ==

= 1.0 =

* FIRST RELEASE VERSION - Previous versions were non-Wordpress.
