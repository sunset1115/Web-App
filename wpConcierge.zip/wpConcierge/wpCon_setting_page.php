<?php
global $wpdb;
$apikey = get_option('appkey');
$buttext = get_option('btntxt')?get_option('btntxt'):'Live Chat';
$btncolor = get_option('btncolor')?get_option('btncolor'):'#FFFFFF';
$email = get_option('email');
$telnum = get_option('telnum');
$link = get_option('link');
$aoption = get_option('aoption')?get_option('aoption'):0;
$optionval = "";
if($aoption) $optionval = 'checked';

?>
<div class='wrap forCon'>
	<div id="conStateDiv" class="update-nag forHiddenState">
		Concierge Options Saved...
	</div>
	<form>
	<div class="rows">
		<label>Application Key</label>
		<input type='text' placeholder='Insert Your Application Key' class="forAppkey" value="<?php echo $apikey;?>" required/>
	</div>
	<div class="rows forButton">
		<fieldset>
			<legend>Standard Button</legend>		
			<p><div class='forLabel'>Text</div>
				<input type="text" placeholder='Live Chat' value='<?php echo $buttext;?>' class='for-but-text' required/>
			</p>
			<p><div class='forLabel'>Color</div>	
				<input type='color' value='<?php echo $btncolor;?>' class="for-but-color"/>				
			</p>
		</fieldset>		
	</div>
	<div class="rows forFallback">
		<fieldset>
			<legend>Fallback Options</legend>		
			<p><div class='forLabel'>Email</div>
				<input type="mail" placeholder='Type your email' value='<?php echo $email;?>' class='for-email' required/>
			</p>
			<p><div class='forLabel'>Tel-number</div>
				<input type="text" placeholder='Type your Telephone Number' value='<?php echo $telnum;?>' class='for-number'/>
			</p>
			<p><div class='forLabel'>Link</div>
				<input type="text" placeholder='Type your Link' value='<?php echo $link;?>' class='for-link'/>
			</p>			
		</fieldset>	
	</div>
	<div class="rows">
		<label style="padding-top: 10px; display: inline-flex;">Audio Calls</label>
		<label class="switch">
			<input id='audioOption' class="switch-input" type="checkbox" <?php echo $optionval;?>/>
			<span class="switch-label" data-on="On" data-off="Off"></span> 
			<span class="switch-handle"></span> 
		</label>
	</div>
	<div class="rows">
		<input type='button' class='for-btn-save' value='Save Settings'/>
	</div>
	</form>
</div>
