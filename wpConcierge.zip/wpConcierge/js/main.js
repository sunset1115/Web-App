jQuery(document).ready(function() {
	jQuery(".for-btn-save").click( function() {
		var re = /^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;

		var appKey = jQuery(".forAppkey").val();
		appKey = appKey.trim();
		if(appKey==""){
			alert('You have to input \'Application Key\'');
			return;
		}

		var btnText = jQuery(".for-but-text").val();
		btnText = btnText==""?'Live Chat':btnText;

		var btnColor = jQuery(".for-but-color").val();
		btnColor = btnColor==""?"#FFFFFF":btnColor;
		
		var email = jQuery(".for-email").val();		
		if(email=="" || !re.test(email)){
			alert("You have to input your valid email");
			return;
		}

		var telNum = jQuery(".for-number").val();
		var link = jQuery('.for-link').val();

		var aOption = 0;
		if(jQuery("#audioOption").is(':checked')) aOption=1;
		
		jQuery.post('/wp-admin/admin-ajax.php', {
			appkey: appKey,
			btntxt: btnText,
			btncolor: btnColor,
			email: email,
			telnum: telNum,
			link: link,
			aoption: aOption,
			'action': 'wpCon_setting'
		}, function(res) {
			jQuery("#conStateDiv").removeClass('forHiddenState');
			/*setTimeout(function() {
				jQuery("#conStateDiv").addClass('forHiddenState');
			}, 3000);*/
		});
	});
});