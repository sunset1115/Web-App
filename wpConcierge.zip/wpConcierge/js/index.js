jQuery(document).ready(function() {
	jQuery.post('/wp-admin/admin-ajax.php',{
		'action': 'wpCon_getoption'
	}, function(res) {
		eval('var options = ' + res);
		
		concierge.setApplicationKey(options.appkey);
		concierge.setCustomerName(options.btntxt);            
		concierge.setCustomAttributes({
			color: options.btncolor,
			text: options.btntxt
		});            
		jQuery('.forConButton input').css('background-color', options.btncolor);
		concierge.setFallbackOptions({
			fallbackPhoneNumber:res.telnum,
			fallbackEmail:res.email,
			fallbackWebsite:res.siteurl,
		});
		var aoption = false;
		if(res.aoption) aoption = true;
		concierge.allowAudioCalls(aoption);
		concierge.addDefaultButton();

		jQuery("a[href*='https://websdk.live.gotoassist.com/index.html?']").css('background-color', options.btncolor);
		jQuery("a[href*='https://websdk.live.gotoassist.com/index.html?']").html(options.btntxt);
	});
});