<?php
/*
Plugin Name: wpConcierge
Plugin URI: http://wordpress.org/
Description: wpConcierge is quite possibly the best way to add <strong> Concierge Chat Funcion </strong> in your site.
Version: 1.0
Author: Sunset.co
Author URI: http://sunset1115.com
License: GPLv2 or later
Text Domain: concierge
*/

/*  Copyright 2016  Sunset.co  (email : sunset1115@yahoo.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License, version 2, as 
    published by the Free Software Foundation.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

function wpCon_head_function() {
	wp_register_style('wpCon-main', plugins_url('css/main.css', __FILE__));
    wp_enqueue_style('wpCon-main');
    wp_register_script('wpCon_js', plugins_url('js/main.js', __FILE__));
    wp_enqueue_script('wpCon_js');
    echo "thank";
}

add_action('admin_enqueue_scripts', 'wpCon_head_function');

function wpCon_admin_menu() {
    add_menu_page('Concierge Setting', 'Concierge', 'administrator', 'Concierge', 'wpCon_setting_page_funtion');    
}

function wpCon_setting_page_funtion() {
    include('wpCon_setting_page.php');
}

add_action('admin_menu', 'wpCon_admin_menu');

function wpCon_setting_ajax_function() {
    $val = $_POST;
    foreach ($val as $key => $value) {
        update_option($key, $value);
    }
    die();
}

add_action('wp_ajax_wpCon_setting', 'wpCon_setting_ajax_function');

function wpCon_livechat_function() {    
    wp_enqueue_script('wpcon_skd_lib','https://websdk.live.gotoassist.com/concierge.min.js');    
    wp_enqueue_script('wpcon_index', plugins_url('js/index.js', __FILE__));     
}

function wpCon_shortcode_loading_function() {
    add_shortcode('wpcon_livechat', 'wpCon_livechat_function');    
}

add_action('init', 'wpCon_shortcode_loading_function');

function wpCon_getoption_ajax_function() {
    $ret = array(
        'appkey'=>get_option('appkey'),
        'btntxt'=>get_option('btntxt'),
        'btncolor'=>get_option('btncolor'),
        'email'=>get_option('email'),
        'telnum'=>get_option('telnum'),
        'siteurl'=>get_option('link'),
        'aoption'=>get_option('aoption'),
        );
    echo json_encode($ret);
    die();
}

add_action('wp_ajax_wpCon_getoption', 'wpCon_getoption_ajax_function');
add_action('wp_ajax_nopriv_wpCon_getoption', 'wpCon_getoption_ajax_function');
?>