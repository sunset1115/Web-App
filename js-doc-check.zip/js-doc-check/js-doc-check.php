<?php
/*
Plugin Name: javascript doc file checking plugin
Plugin URI: http://sunset.com
Description: This plugin adds functionalities to upload the docs and count the totoal words in doc.
Version: 1.1
Author: Sunset
Author URI: 
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
*/

DEFINE("JDC_PLUGINFILE", __FILE__);
DEFINE("JDC_DIR", '/'.substr(WP_PLUGIN_DIR, strlen(ABSPATH)) .'/'.dirname(plugin_basename (__FILE__)).'/');


/**
*  widget class
*/
class WordsCountWidget extends WP_Widget
{
	
	public function __construct()
	{
		$widget_ops = array('classname'=>'words_count_widget', 'description'=> 'Words Count Widget');
		parent:: __construct('words_count', 'Words Count', $widget_ops);
	}

	public function form( $instance) {

	}

	public function update( $new_instance, $old_instance ) {

	}

	//It's widget area of sidebar of page
	public function widget( $args, $instance ) {
		extract($args);
		echo $before_widget;
		echo $before_title . '' . $after_title;
		
        echo '<script type="text/template" id="qq-template-manual-trigger">
        <div class="qq-uploader-selector qq-uploader" qq-drop-area-text="Drop files here">
            <div class="qq-total-progress-bar-container-selector qq-total-progress-bar-container">
                <div role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" class="qq-total-progress-bar-selector qq-progress-bar qq-total-progress-bar"></div>
            </div>
            <div class="qq-upload-drop-area-selector qq-upload-drop-area" qq-hide-dropzone>
                <span class="qq-upload-drop-area-text-selector"></span>
            </div>
            <div class="buttons">
                <div class="qq-upload-button-selector qq-upload-button">
                    <div>Upload files</div>
                </div>                 
            </div>
            <span class="qq-drop-processing-selector qq-drop-processing">
                <span>Processing dropped files...</span>
                <span class="qq-drop-processing-spinner-selector qq-drop-processing-spinner"></span>
            </span>
            <ul class="qq-upload-list-selector qq-upload-list" aria-live="polite" aria-relevant="additions removals">
                <li>
                    <div class="qq-progress-bar-container-selector">
                        <div role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" class="qq-progress-bar-selector qq-progress-bar"></div>
                    </div>
                    <span class="qq-upload-spinner-selector qq-upload-spinner"></span>
                    <img class="qq-thumbnail-selector" qq-max-size="100" qq-server-scale>
                    <span class="qq-upload-file-selector qq-upload-file"></span>
                    <span class="qq-edit-filename-icon-selector qq-edit-filename-icon" aria-label="Edit filename"></span>
                    <input class="qq-edit-filename-selector qq-edit-filename" tabindex="0" type="text">
                    <span class="qq-upload-size-selector qq-upload-size"></span>
                    <button type="button" class="qq-btn qq-upload-cancel-selector qq-upload-cancel">Cancel</button>
                    <button type="button" class="qq-btn qq-upload-retry-selector qq-upload-retry">Retry</button>
                    <button type="button" class="qq-btn qq-upload-delete-selector qq-upload-delete">Delete</button>
                    <span role="status" class="qq-upload-status-text-selector qq-upload-status-text"></span>
                </li>
            </ul>

            <dialog class="qq-alert-dialog-selector">
                <div class="qq-dialog-message-selector"></div>
                <div class="qq-dialog-buttons">
                    <button type="button" class="qq-cancel-button-selector">Close</button>
                </div>
            </dialog>

            <dialog class="qq-confirm-dialog-selector">
                <div class="qq-dialog-message-selector"></div>
                <div class="qq-dialog-buttons">
                    <button type="button" class="qq-cancel-button-selector">No</button>
                    <button type="button" class="qq-ok-button-selector">Yes</button>
                </div>
            </dialog>

            <dialog class="qq-prompt-dialog-selector">
                <div class="qq-dialog-message-selector"></div>
                <input type="text">
                <div class="qq-dialog-buttons">
                    <button type="button" class="qq-cancel-button-selector">Cancel</button>
                    <button type="button" class="qq-ok-button-selector">Ok</button>
                </div>
            </dialog>
        </div>
    </script>';        
        echo "<div id='fine-uploader-manual-trigger'></div>";

        $myAction = $_SERVER['PHP_SELF'] . '?page=upload';
        echo "<input type='hidden' id='actionUrl' value='".$myAction."'/>";
        echo "<input type='hidden' id='baseUrl' value='".JDC_DIR."'/>";
        echo "<input type='hidden' id='sourceUrl' value='".admin_url('admin-ajax.php')."'/>";		
	}
}

function wordscount_register_widgets() {
	register_widget('WordsCountWidget');
}

/*== including the external css and js file in page*/
function jdc_frontpage_scrpts() {
    wp_register_style('jdc_main_css', plugins_url('css/main.css', __FILE__));
	wp_enqueue_style('jdc_main_css');
    wp_register_style('jdc_fineupload_css', plugins_url('css/fine-uploader.new.min.css', __FILE__));
	wp_enqueue_style('jdc_fineupload_css');
    wp_register_script('jdc_jquery', plugins_url('js/jquery.js', __FILE__));
	wp_enqueue_script('jdc_jquery');
    wp_register_script('jdc_fineupload_js', plugins_url('js/all.fine-uploader.min.js', __FILE__));
    wp_enqueue_script('jdc_fineupload_js');
    wp_register_script('jdc_main_js', plugins_url('js/main.js', __FILE__));
    wp_enqueue_script('jdc_main_js');		
}

function jdc_load_ajax_function() {
    $uploads = wp_upload_dir();
    $todaydirname = $uploads['basedir'].'/js-doc-upload/'.date("Y-m-d");
    
    $filename = $todaydirname."/".$_POST['filename'];
    
    $filetype = substr($filename, strripos($filename, "."));
    $txt = "";    
    require('class.pdf2text.php');
    require('doc2txt.class.php');
    
    if(strpos($filetype, "pdf") !== false){
        $a = new PDF2Text();
        $a->setFilename($filename);
        $a->decodePDF();
        $txt = $a->output();        
    }else if(strpos($filetype, "doc") !== false){
        $docObj = new Doc2Txt($filename);          
        $txt = $docObj->convertToText();                
    }else {
        $txt = file_get_contents($filename);                
    }  
    
    /* ======= pay amount calculating =================*/  
    $count = str_word_count($txt);
    $amount = 5;
    if($count > 500) {
        $remain = $count - 500;
        $amount += $remain * 0.05;
    }
    
    echo json_encode(array('count'=>$count, 'amount' => $amount));
    die;
}

function jdc_file_upload_function() {
    
    if(sizeof($_FILES["qqfile"]) > 0) {

        $uploads = wp_upload_dir();
        $todaydirname = $uploads['basedir'].'/js-doc-upload/'.date("Y-m-d");

        if ( ! file_exists( $todaydirname ) ) {
            wp_mkdir_p( $todaydirname );
        }
        $filename = $todaydirname."/".$_FILES['qqfile']['name'];                        
        
        if ($_FILES["qqfile"]["error"] == UPLOAD_ERR_OK) {
            move_uploaded_file( $_FILES["qqfile"]["tmp_name"], $filename);
        }        
    }
    echo json_encode(array("success"=> true));    
    wp_die();
}

function jdc_mail_ajax_function() {
    $filename = ABSPATH.JDC_DIR."uploads/".$_POST['filename'];
    $attachments = array($filename);
    $headers = "From : My name <leonid.vanderlip@outlook.com>"."\r\n";
    wp_mail('paperpolish@outlook.com', 'New Documents', 'Here is new documants to polish');
    die;
}


add_action('widgets_init', 'wordscount_register_widgets');

function jdc_front_init() {
    add_action( 'wp_enqueue_scripts', 'jdc_frontpage_scrpts' );
    add_action('wp_ajax_jdcload_ajax_function', 'jdc_load_ajax_function');    
    add_action('wp_ajax_nopriv_jdcload_ajax_function', 'jdc_load_ajax_function');
    add_action('wp_ajax_jdc_file_upload_function', 'jdc_file_upload_function');
    add_action('wp_ajax_nopriv_jdc_file_upload_function', 'jdc_file_upload_function');    
    add_action('wp_ajax_jdc_mail_function', 'jdc_mail_ajax_function');
    add_action('wp_ajax_nopriv_jdc_mail_function', 'jdc_mail_ajax_function');
    
}
add_action('init', 'jdc_front_init');
?>