jQuery(document).ready(function() {
    
    var baseUrl = jQuery("#baseUrl").val();
    var sourceUrl = jQuery("#sourceUrl").val();
    var targetUrl = jQuery("#actionUrl").val();

    var payamount = 0;
    var filename = '';
    var manualUploader = null;

    if(document.body.contains(document.getElementById('qq-template-manual-trigger'))){
        manualUploader = new qq.FineUploader({
            element: document.getElementById('fine-uploader-manual-trigger'),
            template: 'qq-template-manual-trigger',
            request: {
                endpoint: '/wp-admin/admin-ajax.php',
                params: {
                    "action": "jdc_file_upload_function"
                },
                type: 'GET' 
            },
            thumbnails: {
                placeholders: {
                    waitingPath: baseUrl + '/image/placeholders/waiting-generic.png',
                    notAvailablePath: baseUrl + '/image/placeholders/not_available-generic.png'
                }
            },        
            autoUpload: true,
            debug: false,
            callbacks: {
                onComplete: function(id, name, response) {                
                    
                    if (response.success) {
                        var data = {
                            'filename': name,
                            action: 'jdcload_ajax_function'
                        }

                        filename = name;

                        jQuery.post(sourceUrl, data, function(res) {                         
                            eval("var result = " + res);                       
                            if(parseInt(result.count) == 0){
                                alert("This can't be counted words in it");
                                return;
                            }
                            //jQuery("#wd_cnt").html(result.count);
                            if(!isNaN(result.amount)) payamount = parseFloat(result.amount);
                            jQuery("form #qppamountdefault").val(result.amount);                                                
                        });
                    }                
                }
            }
        });    
        
    }

    
    /*qq(document.getElementById("trigger-upload")).attach("click", function() {
        manualUploader.uploadStoredFiles();
    }); */     
    
    jQuery("#frmPaymentdefault #submit").click( function(evt) {
        var val = jQuery("form #qppamountdefault").val();
        if(!isNaN(val)) val = parseFloat(val);
        else{
            jQuery("#frmPaymentdefault .qpp-blurb").css("color", "red");
            jQuery("#frmPaymentdefault .qpp-blurb").html("You have to imput correct numbers");
            evt.preventDefault();
            return;
        }

        if(val < payamount) {
            jQuery("#frmPaymentdefault .qpp-blurb").css("color", "red");
            jQuery("#frmPaymentdefault .qpp-blurb").html("You have to pay enough coins");            
            evt.preventDefault();
            return;
        } else {
            var data = {
                'filename' : filename,
                'action' : 'jdc_mail_function'
            };
            
            jQuery.post(sourceUrl, data, function(res) {
                console.log(res);
            });            
        }        
    });

});