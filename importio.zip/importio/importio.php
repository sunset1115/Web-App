<?php
/*
Plugin Name: Import.io api
Version: 1.0.1
Plugin URI: http://www.3cc.org/scripts/wp-seatt-simple-event-attendance/
Author: Leonid Vanderlip
Author URI: http://www.3cc.org
Description: Get the data from other sites, and Shows it as list, so it is real crawler. It is tweaked from simple-event plugin.
*/
global $seatt_db_version;
$seatt_db_version = "1.1.2";
include('importio_include.php');

function seatt_install() {
	global $wpdb;
	global $seatt_db_version;
	require_once(ABSPATH . 'wp-admin/includes/upgrade.php');
   
	// Install tables
	$sql = "CREATE TABLE " . $wpdb->prefix . "_events (
		eventid mediumint(9) NOT NULL AUTO_INCREMENT,
		eventname text NOT NULL,
		price text NOT NULL,
		playdate text NOT NULL,
		merchant text NOT NULL,
		url text NOT NULL,
		ticket text ,
		upload_date date NOT NULL,
		UNIQUE KEY id (eventid)
		) ENGINE = MYISAM CHARACTER SET utf8 COLLATE utf8_general_ci;";
	dbDelta($sql);

   add_option("seatt_db_version", $seatt_db_version);
   
    $installed_ver = get_option( "seatt_db_version" );

   if ($installed_ver != $seatt_db_version) {

      $sql = "CREATE TABLE " . $wpdb->prefix . "_events (
		eventid mediumint(9) NOT NULL AUTO_INCREMENT,
		eventname text NOT NULL,
		price text NOT NULL,
		playdate text NOT NULL,
		merchant text NOT NULL,
		url text NOT NULL,
		ticket text ,
		upload_date date NOT NULL,
		UNIQUE KEY id (eventid)
		) ENGINE = MYISAM CHARACTER SET utf8 COLLATE utf8_general_ci;";
      dbDelta($sql);

      update_option( "seatt_db_version", $seatt_db_version );
  }
}

function seatt_uninstall() {
	global $wpdb;
   
	// Remove tables
	$wpdb->query("DROP TABLE IF EXISTS " . $wpdb->prefix . "_events");	
 	
	// Remove option
   delete_option("seatt_db_version");
}


register_activation_hook( __FILE__, 'seatt_install' );
register_uninstall_hook( __FILE__, 'seatt_uninstall' );

function seatt_update_db_check() {
    global $seatt_db_version;
    if (get_site_option('seatt_db_version') != $seatt_db_version) {
        seatt_install();
    }
}

add_action('seatt_loaded', 'seatt_update_db_check');

function importio_admin() {  
	include('importio_admin.php');	
}

function seatt_admin_actions() {
	add_menu_page("Tickets", "Tickets", "level_3", "leo_tickets", "importio_admin" );	
}

add_action('admin_menu', 'seatt_admin_actions');

function seatt_func( $atts ) {
	extract( shortcode_atts( array(
		'event_id' => '1',
	), $atts ) );

	return seatt_form("{$event_id}");
}
add_shortcode( 'seatt-form', 'seatt_func' );

?>