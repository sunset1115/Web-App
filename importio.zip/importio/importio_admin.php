<?php global $wpdb; ?>
<div class="wrap" ng-app="app" ng-controller="MainCtrl">  
<?php


//get data with api
if(isset($_POST['sub_type'])) {
	
	//var_dump($_POST);
	$sub_type = $_POST["sub_type"];

	if($sub_type == "add"){		//get data from api
		$data = $_POST["data"];
		
		/*if($data){*/
		$rows = explode("&$$&", $data);
		$value = "";

		for($i = 0; $i < sizeof($rows) - 1; $i++) {
			
			$ktemp = explode("&;&", $rows[$i]);
			
			$value .= ",('".$ktemp[0]."',";
			$value .= "'".$ktemp[1]."',";
			$value .= "'".$ktemp[2]."',";
			$value .= "'LivefootbalTickets.com',";
			$value .= "'".$ktemp[3]."',";
			$value .= "'".$ktemp[4]."',";
			$value .= "'".date("Y-m-d")."')";								
		}
		$value = substr($value, 1);
		if($value != ""){
			$sql = "insert into wp__events(eventname, price, playdate, merchant, url, ticket, upload_date) values".$value;			
			$wpdb->query($sql);	
		}			
		
	}		
  }
?>	
<style>
	.leo_price_table{
		width: 90%;
		border: 1px;
	}

	.leo_price_table tr:first-child{
		height: 30px;
		text-align: center;
		vertical-align: middle;
		color: #666;
		border: 0px !important;
	}

	.leo_price_table tr{
		height: 25px;
	}
	.leo_price_table th{
		/*border: 0px !important;*/
	}

	.leo_but{
		width: 80px;
		margin-left: 20px;
		margin-top: 20px;
	}

	#wpbody{
		height: 80%;
	}

	#wpbody-content{
		    height: 600px;%;
	}

	.wrap{
		height: 500px;
	}

	.fortable{
		border: 1px solid #ccc;
	    height: 350px;
	    bottom: 100px;
	    position: fixed;
	    width: 90%;
	    overflow-y: auto; 
	}

	.fortable table{
		position: relative;
		width: 100%;		
	}

</style>
<link rel="stylesheet" href="<?php echo plugins_url();?>/importio/js/angular-csp.css" type="text/css" media="screen">
<link rel="stylesheet" href="<?php echo plugins_url();?>/importio/js/loading-bar.min.css" type="text/css" media="screen">
<div>
<p>Please Click Get button in order to get current tickets information from livefootballtickets.com</p>
<p>If you haven't correct api, or have deleted it, nothing will be displayed.</p>
<legend>
	<p> <b>Merchant:</b> LivefootbalTickets.com</p>
	<p> <b>Date:   </b><?php echo date("Y-m-d");?></p>	
</legend>
<p>
	<form name="ticket_add_form" id="ticket_add_form" method="post" action="<?php echo str_replace( '%7E', '~', $_SERVER['REQUEST_URI']); ?>">
		<input type="hidden" name="data" id="data" value="">
		<input type="hidden" name="sub_type" id="sub_type" value="">
		<input type="hidden" name="option" id="option" value="">
	</form>

	<div width="100%">	
	<div style="display:inline-block; float:left">
		<input class="leo_but" type="button" value="Get" ng-click="doGet()">
		<input class="leo_but" type="button" value="Save" ng-click="doSave()">
		<!-- <input class="leo_but" type="button" value="Delete" ng-click="doDelete()"> -->
	</div>
	</div>
</p>
</div>  

<div class="fortable">
<table class="leo_price_table" width="auto" border="1" width="95%" align="left" cellpadding="0" cellspacing="0">
    <tr>
        <th align="center" scope="col" style="width:20px">No</th>
        <th align="center" scope="col">EventName</th>
        <th align="center" scope="col">Price</th>
        <th align="center" scope="col">Date</th>
        <th align="center" scope="col">Tickets Information</th>
        <th align="center" scope="col" style="border-right: 1px solid #a0a5aa;width:30%">Url</th>
    </tr>
    <?php
	// Get all listed events
	$now = date("Y-m-d");
    $events = $wpdb->get_results("SELECT * FROM ".$wpdb->prefix."_events where upload_date like '%".$now."%' ORDER BY eventid DESC");        
    echo "<script> var kval = eval(".json_encode($events).");</script>";
    ?>
    
    <tr ng-repeat="row in rows" ng-init="rows">
        <td>{{$index+1}}</td>
        <td>{{row.eventname}}</td>
        <td>{{row.price}}</td>
        <td>{{row.playdate}}</td>
        <td>{{row.ticket}}</td>
        <td>{{row.url}}</td>        
    </tr>
    <tr>
    	<td colspan="6" style="border-bottom: 1px; border-left: 0px;"></td>
    </tr>    
</table>
</div>
<script src="<?php echo plugins_url();?>/importio/js/angular.min.js" type="text/javascript"></script>
<script src="<?php echo plugins_url();?>/importio/js/loading-bar.min.js" type="text/javascript"></script>
<script src="<?php echo plugins_url();?>/importio/js/angular-endless-scroll.min.js" type="text/javascript"></script>
<script>

	angular.module('app',['angular-loading-bar'])
	.config(['cfpLoadingBarProvider', function(cfpLoadingBarProvider) {
		cfpLoadingBarProvider.includeBar = true;
		cfpLoadingBarProvider.includeSpinner = true;
	}])
	.controller('MainCtrl', ['$scope', 'IoService', 'cfpLoadingBar', '$http', function($scope, IoService, cfpLoadingBar, $http) {
		
		var paths = null;
		var rows = [];


		$scope.rows = kval;
		$scope.datas = IoService.create();

		
		function init() {
			cfpLoadingBar.start();
			var res = IoService.create();
			res.then(function(response) {
				cfpLoadingBar.complete();
				var data = response.data.results;
				if(data && data.length>0){
					paths = data;
				}
			}, function(err) {
				alert("Sorry. Cannot connect server. Reconnect later");
			});
		}

		init();

		$scope.doGet = function() {
			if(paths && paths.length > 0){
				var res = IoService.getPriceData(paths);
				res.then(function(response) {
					displayData(response);
				}, function(err) {
					alert(err.error);
				});
			}
		}

		$scope.doSave = function() {		

			var temps = $scope.rows;
			if(temps.length > 0){
				var postval = "";				
				temps.forEach( function(row) {
					postval += row.eventname + "&;&";
					postval += row.price + "&;&";
					postval += row.date + "&;&";
					postval += row.url + "&;&";
					postval += row.ticket + "&$$&";					
				});

				jQuery("#sub_type").val("add");
				jQuery("#data").val(postval);
				jQuery("form").submit();
				return;				
			}else{
				alert("Empty Data");
			}
		}

		function displayData(rows) {
			var rest = new Array();
			if(rows && rows.length > 0){
				rows.forEach(function(row) {
					var kkg = row.data.results[0];
					var url = row.data.pageUrl;
					var eventname = kkg.eventname;
					var tdate = kkg.date;
					var price = kkg.price;
					var merchant = kkg.merchant;

					if(price && price.length > 0){
						price.forEach(function(a) {
							var apos = a.indexOf("BUY");
							var tick = a.substr(0, apos);
							var price = a.substr(apos + 3, a.indexOf(")") - apos - 1);
							var temp = {eventname: eventname, 
								price: price, 
								date: tdate, 
								merchant: merchant,
								ticket: tick,
								url: url
							};
							rest.push(temp);
						});
					}
				});
				setTimeout(function() {
					$scope.rows = rest;
					$scope.$apply();
				});
			}
		}

	}])
	.factory("IoService", ['$http', '$q', function($http, $q) {
		var data = {};
		return {
			create: function() {
				var deferred = $q.defer();
				var url = "https://api.import.io/store/connector/bba7705f-3150-421a-be7b-e9b2d1c9e177/_query?input=webpage/url:http%3A%2F%2Fwww.livefootballtickets.com%2F&&_apikey=9730b6c101ec48f7ba31709bf195f20c1051c19b0f65bf2eb78e0f284a7657310002676115b630ee7958e811af16dd822fee3034c8263c50e283cf4093cc931e4ebe76cdf4fb72c6c302524fd85da933";
				deferred.resolve($http.get(url));
				return deferred.promise;
			},

			getPriceData: function(rows) {
				var deferred = $q.defer();
				
				var promises = rows.map(function(row) {
					var url = "https://api.import.io/store/connector/0cff478c-2bab-4fc2-915c-385ff01ea507/_query?input=webpage/url:" + encodeURI(row.my_column_5) + "&&_apikey=9730b6c101ec48f7ba31709bf195f20c1051c19b0f65bf2eb78e0f284a7657310002676115b630ee7958e811af16dd822fee3034c8263c50e283cf4093cc931e4ebe76cdf4fb72c6c302524fd85da933"
					return $http.get(url).then(null, function(response) {
						return $q.resolve(response);
					});
				});

				return $q.all(promises);
			}
		}
	}]);
</script>
